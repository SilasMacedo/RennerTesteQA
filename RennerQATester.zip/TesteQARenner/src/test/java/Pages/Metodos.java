package Pages;

import org.openqa.selenium.By;

public class Metodos extends OpenBrowser {


	
	/**
	 * Metodo para clicar no elemento
	 * @param elemento
	 */
	public void clicar(By elemento) {
		try {
			driver.findElement(elemento).click();
		} catch (Exception e) {
			System.err.println("******** Erro ao clicar ********" + e.getCause());
		}
	}

	/**
	 * Metodo para escrever
	 * @param elemento
	 * @param texto
	 */
	public void escrever (By elemento, String texto) {
		try {
			driver.findElement(elemento).sendKeys(texto);	
		} catch (Exception e) {
			System.out.println("========== Erro ao digitar ============" + e.getCause());
		}
	}

	
	public void clicarComSwitch (By elemento) {
		try {
			driver.switchTo().alert();
			driver.findElement(elemento).click();
		} catch (Exception e) {
			System.out.println("========== Erro ao clicar janela ============" + e.getMessage());
		}
		
	}
	

	
}

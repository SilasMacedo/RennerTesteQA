package elementos;

import org.openqa.selenium.By;

public class Elementos {

	
	
	private By SignIn = By.xpath("//a[@class='login'][contains(.,'Sign in')]");
	private	By Email = By.xpath("//input[@id='email']");
	private	By Senha = By.xpath("//input[@type='password']");
	private By BtnSingIn = By.xpath("//span[contains(.,'Sign in')]");
	private By Search = By.xpath("//input[@class='search_query form-control ac_input'][contains(@id,'top')]");
	private By SearchEntrer = By.xpath("//button[@type='submit'][contains(.,'Search')]");
		
	private By Tshirt = By.xpath("//img[contains(@alt,'Faded Short Sleeve T-shirts')]");
	private By Tamanho = By.xpath("//select[@name='group_1'][contains(@id,'1')]");
	private By ColorVerde = By.xpath("//a[contains(@name,'Green')]");
	private By Cart = By.xpath("//span[contains(.,'Add to cart')]");

	private By ColorBlue = By.xpath("//a[contains(@name,'Blue')]");

	private By Blouse = By.xpath("//img[contains(@title,'Blouse')]");
	private By Qtt = By.xpath("//i[contains(@class,'icon-plus')]");
	private By ColorBlack = By.xpath("//a[contains(@name,'Black')]");
		
	
	private By CShop = By.className("//i[contains(@class,'icon-chevron-left left')]");
	private By PShop = By.xpath("(//i[contains(@class,'icon-chevron-right right')])");
	
	private By Avancar = By.xpath("(//span[contains(.,'Proceed to checkout')])[2]");
	private By Iagree = By.xpath("//input[contains(@type,'checkbox')]");
	
	private By pay = By.xpath("//a[@class='cheque'][contains(.,'Pay by check (order processing will be longer)')]");
	private By Confirm = By.xpath("//span[contains(.,'I confirm my order')]");
	
	
	
	private By emailCad = By.xpath("//input[@type='text'][contains(@id,'create')]");
	private By create = By.xpath("//span[contains(.,'Create an account')]");
	
	private By mr = By.xpath("//input[@type='radio'][contains(@id,'gender1')]");
	private By firstName = By.xpath("//input[contains(@name,'customer_firstname')]");
	private By lastName = By.xpath("//input[contains(@name,'customer_lastname')]");
	private By password = By.xpath("//input[contains(@type,'password')]");
	private By dateDay = By.id("days");
		private By day = By.xpath("//option[@value='21'][contains(.,'21')]");
	private By dateMonth = By.id("months");
		private By month = By.xpath("//option[@value='9'][contains(.,'September')]");
	private By dateYears = By.id("years");
		private By years = By.xpath("//option[@value='1982'][contains(.,'1982')]");
	private By addressFirst = By.xpath("//input[@name='firstname']");
	private By addressLast = By.xpath("//input[@name='lastname']");
	private By Address = By.xpath("//input[contains(@name,'address1')]");
	private By city = By.xpath("//input[contains(@name,'city')]");
	private By state = By.xpath("//select[@name='id_state'][contains(@id,'state')]");
		private By Hawaii = By.xpath("//option[@value='11'][contains(.,'Hawaii')]");
	private By fone = By.xpath("//input[@type='text'][contains(@id,'mobile')]");
	private By register = By.xpath("//span[contains(.,'Register')]");
	private By zip = By.xpath("//input[contains(@class,'form-control uniform-input text')]");
	
	
	
	
	
	
	
	
	
	public By getSignIn() {
		return SignIn;
	}
	public By getEmail() {
		return Email;
	}
	public By getSenha() {
		return Senha;
	}
	public By getBtnSingIn() {
		return BtnSingIn;
	}
	public By getSearch() {
		return Search;
	}
	public By getSearchEntrer() {
		return SearchEntrer;
	}
	public By getTshirt() {
		return Tshirt;
	}
	public By getTamanho() {
		return Tamanho;
	}
	public By getColorVerde() {
		return ColorVerde;
	}
	public By getCart() {
		return Cart;
	}
	public By getColorBlue() {
		return ColorBlue;
	}
	public By getCShop() {
		return CShop;
	}
	public By getPShop() {
		return PShop;
	}
	public By getBlouse() {
		return Blouse;
	}
	public By getQtt() {
		return Qtt;
	}
	public By getColorBlack() {
		return ColorBlack;
	}
	public By getAvancar() {
		return Avancar;
	}
	public By getIagree() {
		return Iagree;
	}
	public By getPay() {
		return pay;
	}
	public By getConfirm() {
		return Confirm;
	}
	public By getEmailCad() {
		return emailCad;
	}
	public By getCreate() {
		return create;
	}
	public By getMr() {
		return mr;
	}
	public By getFirstName() {
		return firstName;
	}
	public By getLastName() {
		return lastName;
	}
	public By getPassword() {
		return password;
	}
	public By getDateDay() {
		return dateDay;
	}
	public By getDay() {
		return day;
	}
	public By getDateMonth() {
		return dateMonth;
	}
	public By getMonth() {
		return month;
	}
	public By getDateYears() {
		return dateYears;
	}
	public By getYears() {
		return years;
	}
	public By getAddressFirst() {
		return addressFirst;
	}
	public By getAddressLast() {
		return addressLast;
	}
	public By getAddress() {
		return Address;
	}
	public By getCity() {
		return city;
	}
	public By getState() {
		return state;
	}
	public By getHawaii() {
		return Hawaii;
	}
	public By getFone() {
		return fone;
	}
	public By getRegister() {
		return register;
	}
	public By getZip() {
		return zip;
	}

	

	
	
	
	

}

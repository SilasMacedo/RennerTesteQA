package steps;

import Pages.Metodos;
import Pages.OpenBrowser;
import elementos.Elementos;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;



public class Cart_testes {
	
	OpenBrowser browser = new OpenBrowser();
	Metodos met = new Metodos();
	Elementos el = new Elementos();
	
	
	@Given("que esteja na home {string}")
	public void que_esteja_na_home(String site) {
		browser.openBrowser(site);
	}

	@Given("clicar em sign in")
	public void clicar_em_sign_in() {
	    met.clicar(el.getSignIn());
	}

	@Given("digitar email e senha cadastrados")
	public void digitar_email_e_senha_cadastrados() {
	    met.escrever(el.getEmail(), "testerenner@teste.com");
	    met.escrever(el.getSenha(), "Teste@123");
	}

	@When("clicar no btn sign in")
	public void clicar_no_btn_sign_in() {
	    met.clicar(el.getBtnSingIn());
	}

	@Then("buscar o Faded Short Sleeve T-shirts")
	public void buscar_o_faded_short_sleeve_t_shirts() {
	    met.escrever(el.getSearch(), "Faded Short Sleeve T-shirts");
	    met.clicar(el.getSearchEntrer());
	}

	@When("clicar no produto escolhido")
	public void clicar_no_produto_escolhido() {
	    met.clicar(el.getTshirt());
	}

	@When("escolher cor azul")
	public void escolher_cor_azul() {
	    met.clicar(el.getColorBlue());
	}

	@When("clicar em add to cart")
	public void clicar_em_add_to_cart() {
	    met.clicar(el.getCart());
	}

	@When("clicar em continue shopping")
	public void clicar_em_continue_shopping() {
	    met.clicarComSwitch(el.getCShop()); 
	}

	@When("buscar a Blouse")
	public void buscar_a_blouse() {
	    met.escrever(el.getBlouse(), "Blouse");
	}

	@When("adicionar duas quantidades")
	public void adicionar_duas_quantidades() {
	    met.clicar(el.getQtt());
	}

	@When("escolher cor preta")
	public void escolher_cor_preta() {
	    met.clicar(el.getColorBlack());
	}

	@When("clicar em avancar")
	public void clicar_em_avancar() {
	    met.clicarComSwitch(el.getPShop());
	    met.clicar(el.getAvancar());
	}

	@When("clicar em IAgree")
	public void clicar_em_i_agree() {
	    met.clicar(el.getIagree());
	}

	@When("escolher pagamento")
	public void escolher_pagamento() {
	    met.clicar(el.getPay());
	}

	@When("confirmar")
	public void confirmar() {
	    met.clicar(el.getConfirm());
	}

	@Then("compra realizada com sucesso")
	public void compra_realizada_com_sucesso() {
	    
	}
}

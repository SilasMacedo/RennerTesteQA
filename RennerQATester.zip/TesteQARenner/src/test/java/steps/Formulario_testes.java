package steps;

import Pages.Metodos;
import Pages.OpenBrowser;
import elementos.Elementos;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Formulario_testes {

	
	OpenBrowser browser = new OpenBrowser();
	Metodos met = new Metodos();
	Elementos el = new Elementos();
	
	
	@Given("que esteja na home {string}")
	public void que_esteja_na_home(String site) {
		browser.openBrowser(site);
	}

	@Given("clicar em sign in")
	public void clicar_em_sign_in() {
	    met.clicar(el.getSignIn());
	}
	
	@When("digitar o email {string}")
	public void digitar_o_email(String email) {
	   met.escrever(el.getEmailCad(), email);
	}

	@When("clicar em create an account")
	public void clicar_em_create_an_account() {
		met.clicar(el.getCreate());
	}

	@When("preencher formulario")
	public void preencher_formulario() {
	    met.clicar(el.getMr());
	    met.escrever(el.getFirstName(), "Silas");
	    met.escrever(el.getLastName(), "Macedo");
	    met.escrever(el.getPassword(), "Teste@123");
	    met.clicar(el.getDateDay());
	    met.clicar(el.getDay());
	    met.clicar(el.getDateMonth());
	    met.clicar(el.getMonth());
	    met.clicar(el.getDateYears());
	    met.clicar(el.getYears());
	    met.escrever(el.getAddressFirst(), "Silas");
	    met.escrever(el.getAddressLast(), "Macedo");
	    met.escrever(el.getAddress(), "Mario Covas");
	    met.escrever(el.getCity(), "Hawaii");
	    met.clicar(el.getState());
	    met.clicar(el.getHawaii());
	    met.escrever(el.getZip(), "69705");;
	    met.escrever(el.getFone(), "997108410");
	    met.clicar(el.getRegister());
	    
	}

	@Then("registro com sucesso")
	public void registro_com_sucesso() {
	    
	}
}
